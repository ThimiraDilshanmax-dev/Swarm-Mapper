#pragma once
// Copy to secrets.h. This file contains placeholder values only.
constexpr char WIFI_SSID[] = "ESP32_Hub";
constexpr char WIFI_PASSWORD[] = "password123";
// The computer's Wi-Fi IPv4 address, NOT localhost and not the robot's IP.
constexpr char SERVER_HOST[] = "192.168.4.2";
constexpr uint16_t SERVER_PORT = 8000;
// Obtain from Hardware connection in the local application.
constexpr char ROBOT_TOKEN[] = "vClmCNd3XZgL428bqmUkCgKbTReIQtsNVDvfoWpu";
